// eslint-disable-next-line @typescript-eslint/no-unused-vars
declare namespace Auth {
  type User = {
    email: string,
    password: string,
  }
}
