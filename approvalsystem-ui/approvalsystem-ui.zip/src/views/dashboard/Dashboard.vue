<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

//*===🌊===🌊===🌊===🌊===🌊===🌊===🌊===🌊===🌊===🌊===🌊===🌊Methods

@Component({
  components: {}
})
export default class Dashboard extends Vue {
  //*===🍎===🍎===🍎===🍎===🍎===🍎===🍎===🍎===🍎===🍎===🍎===🍎Data
  //*===🍏===🍏===🍏===🍏===🍏===🍏===🍏===🍏===🍏===🍏===🍏===🍏Computed
}
</script>

<template>
  <v-container>
    <div>Dashboard</div>
  </v-container>
</template>

<style lang="scss"></style>
