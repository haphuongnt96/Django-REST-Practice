<script lang="ts">
import { Vue } from 'vue-property-decorator'
export default class Login extends Vue {
  email = ''
  password = ''
  async handleSubmit(e) {
    //fake user - pass
    //anh.pham@techvify.com.vn - Tur54305
    const [err, res] = await this.$api.authen.doLogin({
      email: this.email,
      password: this.password
    })
    if (!err && res) {
      localStorage.setItem('vue-token', res.data.access)
      localStorage.setItem('vue-token-reset', res.data.refresh)
      this.$router.push({ name: 'approval' })
    } else {
      alert('login fail')
    }
  }
}
</script>

<template>
  <div id="login" class="login-page">
    <div class="login__board">
      <div class="login__board--wrap">
        <h4 class="login__board--title">login page</h4>
        <form @submit.prevent="handleSubmit(this)">
          <div class="login__board--form">
            <label for="">Email</label>
            <input
              type="text"
              class="form-control"
              v-model="email"
              name="email"
              @change="(e) => (this.email = e.target.value)"
            />
          </div>
          <div class="login__board--form">
            <label for="">Password</label>
            <input
              type="password"
              class="form-control"
              v-model="password"
              name="password"
              @change="(e) => (this.password = e.target.value)"
            />
          </div>
          <div class="login__board--button">
            <button class="btn btn__full" type="submit">
              <span>Log in</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped></style>
