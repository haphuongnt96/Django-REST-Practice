import Vue from 'vue'
import AppDefaultLayout from '@/layouts/AppDefaultLayout.vue'

// Init layouts
Vue.component('AppDefaultLayout', AppDefaultLayout)
