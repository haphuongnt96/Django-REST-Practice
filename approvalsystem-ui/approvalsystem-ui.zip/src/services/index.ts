import * as approval from './approval'
import * as authen from './authen'
const $api = {
  approval,
  authen
}
export default $api
